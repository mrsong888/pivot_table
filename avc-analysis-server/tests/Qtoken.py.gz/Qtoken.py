import requests
import json

conn = requests.session()
#获取Token地址
url = 'http://passport.data-x.cn/oauth/token?client_id=avcdata&grant_type=password&username=00020001&password=new.1234&client_secret=new.1234'
headers = {
    'Authorization': 'Basic YXZjZGF0YTpuZXcuMTIzNA=='}
rep = conn.post(url,headers=headers).json()
# req = json.loads(rep.text)
# Token = req.get('access_token')
# Token = rep['access_token']

Token = rep['access_token']

#blackid列表
url_data = 'http://117.23.4.139:20000/hr/api/v1/data/service/r?nodeid=0002'

url_data_1 = 'http://117.23.4.139:20000/datablock/api/v1/data/export/brand_2017_week_sale_count'

url_data_2 = 'http://117.23.4.139:20000/datablock-finance/api/v1/finance/report/sale/finance_report_sale_all_2017'
re_data = conn.get(url=url_data,headers={"Authorization":'bearer '+Token}).json()
id = re_data['']